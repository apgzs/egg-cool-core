# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="1.1.3"></a>
## [1.1.3](https://github.com/xiaomingplus/npm-typescript-boilerplate/compare/v1.1.2...v1.1.3) (2019-11-19)



<a name="1.1.2"></a>
## [1.1.2](https://github.com/xiaomingplus/npm-typescript-boilerplate/compare/v1.1.1...v1.1.2) (2019-11-19)



<a name="1.1.1"></a>
## [1.1.1](https://github.com/xiaomingplus/npm-typescript-boilerplate/compare/v1.1.0...v1.1.1) (2018-12-04)



<a name="1.1.0"></a>
# 1.1.0 (2018-12-04)


### Features

* init ([2554675](https://github.com/xiaomingplus/npm-typescript-boilerplate/commit/2554675))
