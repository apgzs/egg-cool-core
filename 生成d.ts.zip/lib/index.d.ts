export declare abstract class BaseEntity {
    id: number | undefined;
    createTime: Date | undefined;
    updateTime: Date | undefined;
}
